// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.

class Logger {

  static void pageOpen(String msg) {

  }

  static void pageClose(String msg) {

  }

  static void searchWhat(String msg) {
    
  }
}