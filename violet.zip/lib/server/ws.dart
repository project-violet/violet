// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.

import 'package:web_socket_channel/io.dart';

//final channel = IOWebSocketChannel.connect('ws://asdf54as06d5f40asdfasd5f6a0s.com/');

const wss_url = 'ws://asdf54as06d5f40asdfasd5f6a0s.com/';