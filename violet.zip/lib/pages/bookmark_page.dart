// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.
