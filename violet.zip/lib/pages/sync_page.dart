// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.

// 1. Check new data
// 2. Downlaod chunk of data
// 3. Append to database
// 4. Rebuild Tag Data