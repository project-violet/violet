// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.

import 'package:http/http.dart' as http;

// class HttpRequest {
//   String userAgent = "";
//   String accept = "";
//   final http.Client _inner;
  
// }

class HttpWrapper {


}