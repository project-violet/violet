// This source code is a part of Project Violet.
// Copyright (C) 2020. violet-team. Licensed under the MIT License.

import 'package:syncfusion_flutter_core/core.dart';

void registerLicense() {
  SyncfusionLicense.registerLicense("NT8mJyc2IWhia31ifWN9ZmVoYmF8YGJ8ampqanNiYmlmamlmanMDHmghPD8/ITInfTAgNhM0PjI6P30wPD4=");
}