# Violet Flutter App

## Development

### 1. Image Caching

There are two kinds of issue, first is caching search result images caching, 
and the other is image viewer images caching.

Package `cached_network_image` save all of network images, and do not delete saved image data until deleting app.
So, we must have to apply our own caching rules.

### 2. Image Viewer (Scoll View, Photo View)


### 3. Bookmark Management


### 4. Bloc Pattern? Refactoring?

This project started three days after learning `Flutter`, so I don't know much about Flutter. 
If you fix my code, I will follow it.
Thanks.

## Secure and Cryptograpy

### RCE?
