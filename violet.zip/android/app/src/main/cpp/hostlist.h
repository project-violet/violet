#ifndef DPITUNNEL_HOSTLIST_H
#define DPITUNNEL_HOSTLIST_H

bool find_in_hostlist(std::string host);
int parse_hostlist();

#endif //DPITUNNEL_HOSTLIST_H
