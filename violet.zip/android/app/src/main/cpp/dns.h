#ifndef DPITUNNEL_DNS_H
#define DPITUNNEL_DNS_H

int resolve_host(std::string host, std::string & ip);

#endif //DPITUNNEL_DNS_H
